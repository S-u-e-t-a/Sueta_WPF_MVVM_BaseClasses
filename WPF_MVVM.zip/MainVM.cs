﻿using WPF_MVVM_Classes;

namespace $safeprojectname$
{
    internal class MainVM : ViewModelBase
    {
    }
}